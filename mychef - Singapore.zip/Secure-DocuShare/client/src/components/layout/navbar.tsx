import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

export function Navbar() {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <nav className="fixed w-full z-50 bg-white/95 backdrop-blur-sm border-b border-gray-100 py-4">
      <div className="container mx-auto px-4 md:px-6 flex items-center justify-between">
        <Link href="/">
          <a className="text-2xl font-heading font-bold text-primary tracking-tight">
            HireLocalChef<span className="text-muted-foreground text-lg font-normal">.com</span>
          </a>
        </Link>

        <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
          <button onClick={() => scrollToSection("services")} className="hover:text-primary transition-colors">Services</button>
          <button onClick={() => scrollToSection("how-it-works")} className="hover:text-primary transition-colors">How it Works</button>
          <button onClick={() => scrollToSection("pricing")} className="hover:text-primary transition-colors">Pricing</button>
          <button onClick={() => scrollToSection("reviews")} className="hover:text-primary transition-colors">Reviews</button>
        </div>

        <div className="flex items-center gap-4">
          <a href="tel:+6512345678" className="hidden lg:flex items-center gap-2 text-sm font-semibold text-primary">
            <Phone className="w-4 h-4" />
            +65 1234 5678
          </a>
          <Button 
            className="bg-primary hover:bg-primary/90 text-white rounded-none px-6 font-semibold"
            onClick={() => scrollToSection("contact")}
          >
            Book Now
          </Button>
        </div>
      </div>
    </nav>
  );
}
