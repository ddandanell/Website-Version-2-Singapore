import { Link } from "wouter";
import { CONTENT } from "@/lib/constants";

export function Footer() {
  return (
    <footer className="bg-primary text-white py-12 md:py-16">
      <div className="container mx-auto px-4 md:px-6 grid grid-cols-1 md:grid-cols-3 gap-12">
        <div>
          <h3 className="text-2xl font-heading font-bold mb-4">HireLocalChef.com</h3>
          <p className="text-gray-300 text-sm leading-relaxed max-w-xs">
            Professional private chef services in Singapore. Tailored dining experiences for your home or office.
          </p>
        </div>

        <div>
          <h4 className="text-lg font-bold mb-4">Contact</h4>
          <ul className="space-y-2 text-gray-300 text-sm">
            <li>{CONTENT.contact.phone}</li>
            <li>{CONTENT.contact.email}</li>
            <li>{CONTENT.contact.address}</li>
          </ul>
        </div>

        <div>
          <h4 className="text-lg font-bold mb-4">Quick Links</h4>
          <ul className="space-y-2 text-gray-300 text-sm">
            <li><a href="#services" className="hover:text-white transition-colors">Services</a></li>
            <li><a href="#how-it-works" className="hover:text-white transition-colors">How it Works</a></li>
            <li><a href="#pricing" className="hover:text-white transition-colors">Pricing</a></li>
            <li><a href="#contact" className="hover:text-white transition-colors">Book Now</a></li>
          </ul>
        </div>
      </div>
      <div className="container mx-auto px-4 md:px-6 mt-12 pt-8 border-t border-white/10 text-center text-xs text-gray-400">
        <p>&copy; {new Date().getFullYear()} HireLocalChef.com Singapore. All rights reserved.</p>
      </div>
    </footer>
  );
}
